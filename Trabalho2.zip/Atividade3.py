class Carro(object):
    
    def __init__(self,a):
        self.a = a
        self.gasolina = 0
        
    def addGasolina(self,p2):
        self.gasolina = self.gasolina + p2    
    
    def andar(self,quilom):
        self.quilom = quilom
        self.gasolina = (self.gasolina - round(self.quilom/self.a,2))

    def obterGasolina(self):
            return self.gasolina
        

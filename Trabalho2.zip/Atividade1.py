def conver(aux):
    aux = aux/1048576
    return aux

def porcen(aux1,aux2):
    aux3 = ((aux1*100)/aux2)    
    return aux3


arquivo = open('usuarios.txt','r')
lista = [1,2,3,4,5,6]
cont = 0

for linha in arquivo:
    linha = linha.strip()
    lista[cont] = linha 
    cont +=1
    
arquivo.close()
cont=0
nlista = []

for cont in range(0,6):
    nlista.append(lista[cont].split())
    
soma = 0
cont = 0
numeros = [1,2,3,4,5,6]
porcentagens = [1,2,3,4,5,6]

for cont in range(0,6):
    numeros[cont] = round(conver(int(nlista[cont][1])),2)
    soma += numeros[cont]
cont = 0

for cont in range(0,6):
    porcentagens[cont] = round(porcen(numeros[cont],soma),2)
    
novoarquivo = open('relatorio.txt','w+')
teste = 'nome\t {}'.format('-'*30)
texto = novoarquivo.readlines()
texto.append('\tACME Inc\t\tUso do espaço em disco pelos usuários\n\t{}'.format('-'*70))
texto.append('\n\tNr.  Usuário\tEspaço utilizado\t% do uso\n\n')
cont = 0

for cont in range(0,6):
    texto.append('\t{0}    {1}{2}{3} MB{4}{5}%\n'.format(cont+1,nlista[cont][0],' '*(15-len(nlista[cont][0])),numeros[cont],' '*(24-((len(str(numeros[cont])))+len(str(porcentagens[cont])))),porcentagens[cont]))
    
texto.append('\n\tEspaço total ocupado: {0} MB \n\tEspaço médio ocupado: {1} MB'.format(round(soma,2),round(soma/6,2)))                                                                                                                                
novoarquivo = open('relatorio.txt','w')
novoarquivo.writelines(texto)
novoarquivo.close()


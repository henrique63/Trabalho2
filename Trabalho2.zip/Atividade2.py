def reparte(num):
    num = int(num)
    num1 = int(num/1000)
    aux = num%1000
    num2 = int(aux/100)
    aux = aux%100
    num3 = int(aux/10)
    aux = int(aux%10)
    list = [num1,num2,num3,aux]
    return list

def troca(list):
    aux = list[0]
    list[0] = list[2]
    list[2] = aux
    aux = list[1]
    list[1] = list[3]
    list[3] = aux
    nume = list
    return list
    
    

num = input('Digite o número criptografado: ')
numeros = reparte(num)
real = [1,2,3,4]
a=0
for a in range(0,4):
    if numeros[a] >= 6:
        real[a] = (numeros[a] - 6)
    else:
        real[a] = ((10+numeros[a]) - 6)
real = troca(real)
print('O número descriptografado é: {0}{1}{2}{3}'.format(real[0],real[1],real[2],real[3]))

num1 = input('Digite um número para criptografa-lo: ')
numeros1 = reparte(num1)
a=0
real1 = [1,2,3,4]
for a in range(0,4):
        real1[a] = (numeros[a] + 6)%10
real1 = troca(real1)
print('O número criptografado é: {0}{1}{2}{3}'.format(real1[0],real1[1],real1[2],real1[3]))    
